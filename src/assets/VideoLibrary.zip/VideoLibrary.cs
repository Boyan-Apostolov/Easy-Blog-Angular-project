private string name;
private List<Movie> movies;

public VideoLibrary (string name)
{
  //TODO: Добавете вашия код тук …                           
} 

public string Name
{
  //TODO: Добавете вашия код тук …                             
}

public List<Movie> Movies
{
  //TODO: Добавете вашия код тук …                   
}

public void AddMovie(string title, double rating)
{
  //TODO: Добавете вашия код тук …                   
}

public double AverageRating()
{
  //TODO: Добавете вашия код тук …                              
}

public List<string> RemoveMoviesByRating(double rating)
{
  //TODO: Добавете вашия код тук …                             
}

public List<Movie> SortByTitle()
{
  //TODO: Добавете вашия код тук …                             
}

public List<Movie> SortByRating()
{
  //TODO: Добавете вашия код тук …                             
}

public string[] ProvideInformationAboutAllMovies()
{
  //TODO: Добавете вашия код тук …                            
}

public bool CheckMovieIsInVideoLibrary (string title)
{
  //TODO: Добавете вашия код тук …                   
}
