private string title;
private double rating;

public Movie(string title, double rating)
{
  //TODO: Добавете вашия код тук …                     
}

public string Title
{
  //TODO: Добавете вашия код тук …                   
}

public double Rating
{
  //TODO: Добавете вашия код тук …                      
}

public override string ToString()
{
  //TODO: Добавете вашия код тук …                   
}
